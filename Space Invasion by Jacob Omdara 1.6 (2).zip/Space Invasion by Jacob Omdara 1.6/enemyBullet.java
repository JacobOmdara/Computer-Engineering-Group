import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class enemyBullet here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class enemyBullet extends Bullet
{
    // constructor, takes in the bulletSpeed determined by the level
    public enemyBullet (int bulletSpeed)
    {
        // sets the bullet speed from parameter to this bullet speed
        this.bulletSpeed = bulletSpeed;
    }
    
    public void act()
    {
        // runs the hitcheck method
        hitCheck();
        // if the bullet exists
        if (this.getWorld() != null)
        {
            // moves the bullet the speed of bulletSpeed pixels up
            setLocation(getX(), getY() + bulletSpeed);
        }
    }
}
